import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Favlist } from '../favlist';
import { FavMusic } from '../favmusic';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-favourite',
  templateUrl: './favourite.component.html',
  styleUrls: ['./favourite.component.css']
})
export class FavouriteComponent implements OnInit {
  favlist: Favlist[] = [];
  user="";
  fav=new FavMusic();
  message="";

  constructor(private _service : ServiceService,private _router : Router) { }

  ngOnInit(): void {
    this.getFavMusicsList();
    this.user=this._service.getMessage();
  }
  getFavMusicsList(){
    this._service.getFavMusicList().subscribe(data=>{
      this.favlist = data;
    });
  }

    removeMusic(id: any){
    
    if(this._service.getMessage()==""){
      alert("Login With Proper Details")
      return
    }
    this.fav.id=id;
    this.fav.userEmail=this._service.getMessage();
    this._service.setMusicid(id);
    console.log(this.fav);
    this._service.removefavlistFromRemote().subscribe(data=>{
      alert("Track Removed");
    });

  }

  submit(){
    this._router.navigate(['login'])
    }
}
