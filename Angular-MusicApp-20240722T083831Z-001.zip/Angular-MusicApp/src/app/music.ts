export class Music {
    id!: number;
    songName!: string;
    singer!: string;
    songUrl!: string;
    button!: string;
    buttondDisabled: boolean= false;
    constructor(){}
}