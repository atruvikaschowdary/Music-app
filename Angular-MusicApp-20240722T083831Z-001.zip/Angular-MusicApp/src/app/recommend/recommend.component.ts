import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FavMusic } from '../favmusic';
import { Recommended } from '../recommended';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-recommend',
  templateUrl: './recommend.component.html',
  styleUrls: ['./recommend.component.css']
})
export class RecommendComponent implements OnInit {

  recommend:Recommended[]=[]
  constructor(private _service: ServiceService, private _router: Router) { }

  ngOnInit(): void {
    this.getRecMusicList();
  }

  getRecMusicList(){
    this._service.getRecommendedList().subscribe(data=>{
      this.recommend = data;
    });
  }
  submit(){
    this._router.navigate(['login'])
    }
}
