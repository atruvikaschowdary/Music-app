export class User {
    id!: number;
    emailId!: string;
    mobile!: number;
    username!: string;
    password!: string;
    constructor(){}
}
