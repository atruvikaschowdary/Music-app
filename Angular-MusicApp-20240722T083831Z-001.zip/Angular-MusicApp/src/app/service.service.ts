import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User  } from './user';
import { Music } from './music';
import { Favlist } from './favlist';
import { FavMusic } from './favmusic';
import { Image } from './image';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  message="";
  user="";
  musicid: number | undefined;
  private baseURL = "http://localhost:9004/addtolist";
  constructor(private _http : HttpClient) { }

  public loginUserFromRemote(user :User):Observable<any>{  //Comes here the connects to registerControllr.
     console.log("inside");
     
     return this._http.post<any>("http://localhost:9003/loginuser",user)
  }

  public registerUserFromRemote(user :User):Observable<any>{
    return this._http.post<any>("http://localhost:9003/registeruser",user)
  }

  public addtofavlistFromRemote(favlist :Favlist):Observable<any>{
    return this._http.post<any>("http://localhost:9004/addtolist",favlist)
  }
  public removefavlistFromRemote(): Observable<FavMusic>{
    let url=`http://localhost:9004/favlist/{id}`+this.getMusicid();
    return this._http.delete<FavMusic>(url);
  }

  getMusicList(): Observable<Music[]>{
    return this._http.get<Music[]>(`${this.baseURL}`);
  }
  getFavMusicList(): Observable<FavMusic[]>{
    return this._http.get<FavMusic[]>(`http://localhost:9004/favlist/`+this.getMessage())
  }
  
  public getTracks():Observable<any>{  // API 
    return this._http.get("https://api.napster.com/v2.1/tracks/top?apikey=NDQ1ZTI2OWUtMDc3MS00NmZhLTkxODktNzc0NTMzYTJmOWNj");
  }
  setMessage(data: string){
    this.message=data;
  }
  getMessage(){
    return this.message;
  }
  setUser(data: string){
    this.user=data;
  }
  getUser(){
    return this.user;
  }
  
  getUserimage():Observable<Image[]>{
    return this._http.get<Image[]>("http://localhost:9002/files/"+this.getUser);
 }
  setMusicid(data: number){
    this.musicid=data;
  }
  getMusicid(){
    return this.musicid;
  }
   getRecommendedList():Observable<FavMusic[]>{
     return this._http.get<FavMusic[]>("http://localhost:9004/recommended");
   }
  
}