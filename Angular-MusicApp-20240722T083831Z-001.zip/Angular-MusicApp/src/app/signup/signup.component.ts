import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { User } from '../user';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  user= new User();
  msg='';
  message='';
  Selectedfile!: File;
  baseURL: any
  //image= new Image();
  constructor(private _service: ServiceService,private httpClient: HttpClient, private _router : Router) { }

  ngOnInit() {
    
  }
  public onFileChanged(event:any){
    this.Selectedfile=event.target.files[0]
    
  }
  
  onUpload() {
    console.log(this.user.emailId);
    
    const uploadImageData = new FormData();

    uploadImageData.append('file', this.Selectedfile);
    
   
    this.baseURL = "http://localhost:9002/upload/"+this.user.emailId;
    this.httpClient.post(`${this.baseURL}`, uploadImageData, { observe: 'response' })
      .subscribe((response) => {
        if (response.status === 200) {
          this.message = 'Image uploaded successfully';
          return
        } else {
          this.message = 'Image not uploaded successfully';
          alert(this.message);  
        }
      }
      
      );


  }

  signUp(){
    if(this.user.emailId==null || this.user.password==null || this.user.username ==null){
      console.log("null");
      this.message="register failed";
      alert("Please enter Your details")
      return
    }
    if(this.Selectedfile==null){
      this.message="Please Upload Profile picture"
      return
    }
    this.onUpload();

    this._service.registerUserFromRemote(this.user).subscribe(
      data =>{
        console.log("response recieved");
        this.msg="Registration successful";
        alert("Registration successful");
        this._router.navigate(['/login']);

      }
     
    )
    
  }

}
