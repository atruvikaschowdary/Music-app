export class FavMusic {
    id!:number;
    songName!:string;
    singers!:string;
    songUrl!: string;
    userEmail!:string;
    constructor(){}
}
