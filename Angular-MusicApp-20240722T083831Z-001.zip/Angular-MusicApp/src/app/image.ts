export class Image {
    name!: string;
    url!: string;
    type!: string;
    size!: number;
    constructor(){}
    
}