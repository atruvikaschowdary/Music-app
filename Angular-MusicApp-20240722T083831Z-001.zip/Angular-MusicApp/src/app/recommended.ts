export class Recommended {
    id!:number;
    songName!:string;
    singers!:string;
    songUrl!: string;
    userEmail!:string;
    constructor(){}
}
