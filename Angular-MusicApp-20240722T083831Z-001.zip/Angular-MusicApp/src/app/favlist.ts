export class Favlist {
    id!:number;
    songName!:string;
    singers!:string;
    songUrl!: string;
    userEmail!:string;
    constructor(){}
}