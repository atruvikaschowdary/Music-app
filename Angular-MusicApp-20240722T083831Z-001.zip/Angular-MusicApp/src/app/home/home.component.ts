import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Favlist } from '../favlist';
import { ServiceService } from '../service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  music: any[] = []
  favlist = new Favlist();
  msg = "";

  constructor(private _service: ServiceService, private _router: Router) { }

  userid = "";
  url = "";
  ngOnInit(): void {
    this.url="http://localhost:9003/files/"+this.userid;
    this.userid=this._service.getMessage();
    this.getMusic();
  }

   getMusic() {
    this._service.getTracks().subscribe(data => {
      console.log(data);
      this.music = data.tracks;
    })
  }
  submit() {
    this._router.navigate(['login'])
  }
  addtoList(songName: any, singers: any, songUrl: any) {

    this.userid = this._service.getMessage();
    if (this._service.getMessage() == "") {
      alert("Login With Proper Details")
      return
    }
    console.log(this.userid);
    this.favlist.songName = songName;
    this.favlist.singers = singers;
    this.favlist.userEmail = this._service.getMessage();
    this.favlist.songUrl = songUrl;
    this._service.addtofavlistFromRemote(this.favlist).subscribe(data => {
      alert("Added");
    })
    /*
      error => {
        this.msg = "Music is Already in your List"
        alert(this.msg)
        console.log("Exeption Occured");

      } */
  }
}


