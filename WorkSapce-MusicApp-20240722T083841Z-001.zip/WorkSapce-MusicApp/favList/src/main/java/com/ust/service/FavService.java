package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.Favourite;
import com.ust.repository.FavRepository;

@Service
public class FavService {
	@Autowired
	private FavRepository repo;
	
	

	public Favourite saveFav(Favourite fav) {
		return repo.save(fav);
	}

	public Favourite fetchListBySongName(String songName) {
		return repo.findBySongName(songName);
	}

	public Favourite fetchListBySongNameAndUserMail(String songName, String userEmail) {
		return repo.findBySongNameAndUserEmail(songName, userEmail);
	}

	public List<Favourite> getAllFavMusic(String userEmail) {
		return repo.findByUserEmail(userEmail);
	}

	public void deleteFavMusicById(int id) {
		repo.deleteById(id);
	}

	public List<Favourite> getAllRecMusic() {

		return repo.findAll();
	}
}
