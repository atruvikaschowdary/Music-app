package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Favourite {
	@Id
	private int id;
	private String songName;
	private String singers;
	private String userEmail;
	private String songUrl;

	public Favourite() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Favourite(int id, String songName, String singers, String userEmail, String songUrl) {
		super();
		this.id = id;
		this.songName = songName;
		this.singers = singers;
		this.userEmail = userEmail;
		this.songUrl = songUrl;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSingers() {
		return singers;
	}

	public void setSingers(String singers) {
		this.singers = singers;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getSongUrl() {
		return songUrl;
	}

	public void setSongUrl(String songUrl) {
		this.songUrl = songUrl;
	}

}
