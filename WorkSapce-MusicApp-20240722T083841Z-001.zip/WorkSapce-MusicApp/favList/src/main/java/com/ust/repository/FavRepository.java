package com.ust.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ust.model.Favourite;

public  interface FavRepository extends JpaRepository<Favourite, Integer> {
	public Favourite findBySongName(String songName);
	
	List<Favourite> findByUserEmail(String userEmail);
	public Favourite findBySongNameAndUserEmail(String songName,String userEmail);
}
