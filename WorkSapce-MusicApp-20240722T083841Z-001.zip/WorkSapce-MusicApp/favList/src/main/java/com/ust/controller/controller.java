package com.ust.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ust.model.Favourite;
import com.ust.service.FavService;

@RestController
public class controller {

	@Autowired
	private FavService service;

	@PostMapping(path = "/addtolist")
	@CrossOrigin(origins = "http://localhost:4200")
	public Favourite addtoList(@RequestBody Favourite fav) throws Exception {
		String tempMusicName = fav.getSongName();
		String tempUserEmail = fav.getUserEmail();
		Favourite tempFav = service.fetchListBySongNameAndUserMail(tempMusicName, tempUserEmail);
		if (tempFav != null) {
			throw new Exception("This Music is already in your playlist");
		}
		Favourite favObj = service.saveFav(fav);

		return favObj;

	}

	@GetMapping(path = "/favlist/{userEmail}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Favourite> getAllMusic(@PathVariable("userEmail") String userEmail) {
		System.out.println(userEmail);
		List<Favourite> allFavMusic = service.getAllFavMusic(userEmail);
		return allFavMusic;
	}

	@DeleteMapping(path = "/favlist/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public String removeFavMusic(@PathVariable("id") int id) {
		System.out.println(id);
		
		service.deleteFavMusicById(id);
		return "removed";
	}
	
	@GetMapping(path = "/recommended")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Favourite> getRecMusic() { 
		
		List <Favourite> newList = new ArrayList<Favourite>();
		List<Favourite> allFavMusic =  service.getAllRecMusic();
		System.out.println(allFavMusic);
		for(Favourite i : allFavMusic) {
			int flag =0;
			for(Favourite j : newList) {
				if(i.getSongUrl().equals(j.getSongUrl())) {
					flag=1;
					break;
				}
			}
			if (flag==0) {
				newList.add(i);
			}
		}
		return newList;
	}
}
