package com.ust.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.model.Favourite;
import com.ust.service.FavService;

@SpringBootTest
public class FavControllerIntegrationTest {
	
    @Autowired
    private FavService service;
    private Favourite favourite;
    private List<Favourite> musiclist;
    
    @BeforeEach
    public void setUp() {
    	favourite = new Favourite();
    	favourite.setId(45);
    	favourite.setSongName("demoname");
    	favourite.setSingers("demoSingers");
    	favourite.setSongUrl("demoSongUrl");
    	favourite.setUserEmail("demoEmail");
    	musiclist = new ArrayList<>();
    	musiclist.add(favourite);
    }
    
    @AfterEach
    public void tearDown() {
        favourite = null;
    }
    
    @Test
    void givenMusicToSaveThenShouldReturnTheSavedMusic() throws Exception {
    	Favourite savedFavourite = service.saveFav(favourite);
    	assertNotNull(savedFavourite);
    	assertEquals(favourite.getId(),savedFavourite.getId());
    	service.deleteFavMusicById(savedFavourite.getId());
    }

    @Test
    public void givenUserIdThenShouldReturnAllFavouriteMusicOfThatUser() throws Exception {
    	List<Favourite> musicList = service.getAllFavMusic("vk@gmail.com");
    	assertNotNull(musicList);
    }
    
    @Test
    public void givenFavIdThenShouldDeleteTheItem() throws Exception {
    	service.deleteFavMusicById(51);
    	assertEquals(1,1);   	
    }
    
    @Test
    public void ShouldReturnAllRecommendedNews() throws Exception {
    	List<Favourite> musicList = service.getAllRecMusic();
    	assertNotNull(musicList);
    }
    
}
