package com.ust.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;


import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.model.Favourite;


@SpringBootTest
public class FavRepositoryTest {
	
	@Autowired
    private FavRepository repo;
    private Favourite favourite;
    
    @BeforeEach
    public void setUp() {
    	favourite = new Favourite();
    	favourite.setId(1);
    	favourite.setSingers("DemoSingers");
    	favourite.setSongName("demosongName");
    	favourite.setSongUrl("demoSongUrl");
    	favourite.setUserEmail("demoUserEmail");
    	
    	
    }
    
    @AfterEach
    public void tearDown() {
        favourite = null;
    }
    
    @Test
    public void givenBlogToSaveThenShouldReturnSavedMusic() {
        repo.save(favourite);
        Favourite fetchedmusic = repo.findById(favourite.getId()).get();
        assertEquals(1, fetchedmusic.getId());
    }
    
    @Test
    public void givenGetAllMusicThenShouldReturnListOfAllMusic() {
    	Favourite favourite1 = new Favourite(1,"DemoSingers1","demoUserEmail1", "demosongName1" , "demoSongUrl1" );
    	Favourite favourite2 = new Favourite(2,"DemoSingers2","demoUserEmail2", "demosongName2" , "demoSongUrl2" );
        repo.save(favourite1);
        repo.save(favourite2);

        List<Favourite> musicList = (List<Favourite>) repo.findAll();
        assertEquals(2, musicList.get(1).getId());
    }

}