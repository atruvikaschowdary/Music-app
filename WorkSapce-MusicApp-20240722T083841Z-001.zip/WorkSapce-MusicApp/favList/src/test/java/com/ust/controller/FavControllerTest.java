package com.ust.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ust.model.Favourite;
import com.ust.service.FavService;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FavControllerTest {

	private MockMvc mockMvc;
    @Mock
    FavService service;
    @InjectMocks
    private controller favcontroller;
    
    private Favourite favourite;
    private List<Favourite> musiclist;
    
    @BeforeEach
    public void setUp() {
    	MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(favcontroller).build();
        favourite = new Favourite();
    	favourite.setId(1);
    	favourite.setSingers("Demosingers");
    	favourite.setSongUrl("demosongUrl");
    	favourite.setSongName("demosongname");
    	favourite.setUserEmail("demouseremail");
    	musiclist = new ArrayList<>();
    	musiclist.add(favourite);
    }
    
    @AfterEach
    public void tearDown() {
        favourite = null;
    }
    
    @Test
    public void givenMusicToSaveThenShouldReturnSavedMusic() throws Exception {
        when(service.saveFav(any())).thenReturn(favourite);
        mockMvc.perform(post("/addtolist")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(favourite)))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
        verify(service).saveFav(any());
    }
    
    
    @Test
    public void givenUserIdThenShouldReturnAllFavouriteMusicOfThatUser() throws Exception {
        when(service.getAllFavMusic("vk@gmail.com")).thenReturn(musiclist);
        mockMvc.perform(MockMvcRequestBuilders.get("/favlist/vk@gmail.com")
                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(favourite)))
                .andDo(MockMvcResultHandlers.print());
        verify(service).getAllFavMusic("vk@gmail.com");
        verify(service, times(1)).getAllFavMusic("vk@gmail.com");

    }
    
    
    @Test
    public void ShouldReturnAllRecommendedMusic() throws Exception {
        when(service.getAllRecMusic()).thenReturn(musiclist);
        mockMvc.perform(MockMvcRequestBuilders.get("/recommended")
                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(favourite)))
                .andDo(MockMvcResultHandlers.print());
        verify(service).getAllRecMusic();
        verify(service, times(1)).getAllRecMusic();

    }
    
    
    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}